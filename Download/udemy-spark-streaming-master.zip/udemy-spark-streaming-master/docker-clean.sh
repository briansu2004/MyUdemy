#!/bin/bash
docker rm -f $(docker ps -aq)